let num1:number[]=[];
let num2:Array<number> =[];
let num3:Array<number> =new Array();

num1.push(10);
num1.push(10);
num1.push(10);

let names:string[]=new Array();
let info1:any[]=new Array();
//this interface is use to make the type of objects.
interface Employee{
    id:number;
    name:string;
    age:number;
}

let emp1:Employee ={id:101,name:"krishna",age:22};
let emp2:Employee ={id:102,name:"krishna",age:22};
let emp3:Employee ={id:103,name:"krishna",age:22};
let emp4:Employee ={id:104,name:"krishna",age:22};
let emp5:Employee ={id:105,name:"krishna",age:22};


let employees:Array<Employee> = new Array();

employees.push(emp1);
employees.push(emp2);
employees.push(emp3);
employees.push(emp4);
employees.push(emp5);

employees.forEach(e=>console.log(e.id+" "+e.name+" "+e.age));

let res1 = employees.find(e=>e.id==101);            // searching the record from array if present it return that object 
let res2 = employees.find(e=>e.id==1000);           // else return undefined 

let res3 = employees.findIndex(e=>e.id==103);       // searching the record from array if present it return that record index position  
let res4 = employees.findIndex(e=>e.id==1000);       // else return -1 

console.log(res1);
console.log(res2);


console.log(res3);
console.log(res4);






//let num1 = [10,20,30,40,50,60]
//num1.forEach((i)=>document.write("<br>"+i*3))
