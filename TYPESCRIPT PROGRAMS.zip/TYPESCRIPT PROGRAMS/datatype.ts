let a:number = 10;
let fname:string ="jaya";
let result : boolean = true;

let info:any="welcome";
info = false;
info =200;


let b =200;

let lname = "jaya";

let result1 = false;

console.log(b)
console.log(lname)
console.log(result1)

