console.log("welcome to type script");
